# Country-State-City
### Initilization
1. Clone this repository.
2. Create database location and imoport sql file.

![1](https://user-images.githubusercontent.com/34600724/49851088-f7c56300-fe05-11e8-9ef6-e50c71ab5c94.jpg)
![2](https://user-images.githubusercontent.com/34600724/49851092-fb58ea00-fe05-11e8-9668-47fbfe9749ad.jpg)
![3](https://user-images.githubusercontent.com/34600724/49851094-fd22ad80-fe05-11e8-9d1e-8578d99c8a2d.jpg)
![4](https://user-images.githubusercontent.com/34600724/49851099-ff850780-fe05-11e8-98a4-d0e0aae3773d.jpg)
